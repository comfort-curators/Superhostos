'use client';

import { useState } from 'react';
import { useAuth } from '@/components/Navbar';
import { motion } from 'motion/react';
import { MessageSquare, Clock, Edit2, CheckCircle2, Loader2, Power } from 'lucide-react';

const DEFAULT_TEMPLATES = [
  {
    id: 't1',
    name: 'Booking Confirmation',
    trigger: 'Immediately after booking',
    content: 'Hi {guest_name}, thanks for booking {property_name}! We are thrilled to host you. Your reservation is confirmed for {check_in_date} to {check_out_date}. We will send check-in instructions 2 days before your arrival.',
    active: true,
  },
  {
    id: 't2',
    name: 'Check-in Instructions',
    trigger: '2 days before check-in at 10:00 AM',
    content: 'Hi {guest_name}, your trip is coming up! You can check in anytime after 4:00 PM. The smart lock code is {door_code}. The WiFi network is {wifi_name} and the password is {wifi_password}. Let us know if you need anything!',
    active: true,
  },
  {
    id: 't3',
    name: 'First Morning Check-in',
    trigger: 'Day after check-in at 9:00 AM',
    content: 'Good morning {guest_name}! We hope you had a great first night at {property_name}. Is everything to your liking? Please let us know if you need any additional supplies or recommendations for the area.',
    active: true,
  },
  {
    id: 't4',
    name: 'Checkout Instructions',
    trigger: 'Evening before checkout at 5:00 PM',
    content: 'Hi {guest_name}, we hope you enjoyed your stay! Just a reminder that checkout is tomorrow at 11:00 AM. Please start the dishwasher and lock the door behind you. Safe travels!',
    active: true,
  }
];

export default function MessagesPage() {
  const { user, loading: authLoading } = useAuth();
  const [templates, setTemplates] = useState(DEFAULT_TEMPLATES);
  const [editingId, setEditingId] = useState<string | null>(null);

  const toggleActive = (id: string) => {
    setTemplates(prev => prev.map(t => t.id === id ? { ...t, active: !t.active } : t));
  };

  if (authLoading) {
    return (
      <div className="flex h-[60vh] items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-[#FF385C]" />
      </div>
    );
  }

  if (!user) {
    return <div className="text-center py-20 text-gray-500">Please sign in to access automated messages.</div>;
  }

  return (
    <div className="max-w-5xl mx-auto space-y-10 pb-24">
      <div className="flex items-center justify-between border-b border-gray-200 pb-6">
        <div className="flex items-center gap-6">
          <div className="h-16 w-16 rounded-full bg-blue-50 flex items-center justify-center border border-blue-100">
            <MessageSquare className="h-8 w-8 text-blue-600" />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-[#222222] tracking-tight">Automated Messages</h1>
            <p className="text-[#717171] mt-1 font-medium">Manage your scheduled guest communications.</p>
          </div>
        </div>
        <button className="px-6 py-3 bg-[#222222] text-white font-semibold rounded-xl hover:bg-black transition-colors">
          + New Template
        </button>
      </div>

      <div className="grid grid-cols-1 gap-6">
        {templates.map(template => (
          <motion.div 
            key={template.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className={`rounded-2xl border ${template.active ? 'border-gray-200 bg-white shadow-sm' : 'border-gray-200 bg-gray-50 opacity-75'} p-6 transition-all`}
          >
            <div className="flex items-start justify-between mb-6">
              <div>
                <div className="flex items-center gap-3 mb-2">
                  <h3 className="text-xl font-bold text-[#222222]">{template.name}</h3>
                  {template.active ? (
                    <span className="px-2.5 py-1 rounded-full bg-green-100 text-green-700 text-xs font-bold uppercase tracking-wider">Active</span>
                  ) : (
                    <span className="px-2.5 py-1 rounded-full bg-gray-200 text-gray-600 text-xs font-bold uppercase tracking-wider">Paused</span>
                  )}
                </div>
                <div className="flex items-center gap-2 text-sm font-medium text-[#717171]">
                  <Clock className="h-4 w-4" />
                  Trigger: {template.trigger}
                </div>
              </div>
              
              <div className="flex items-center gap-3">
                <button 
                  onClick={() => toggleActive(template.id)}
                  className={`p-2 rounded-lg border transition-colors ${template.active ? 'border-gray-200 text-gray-500 hover:bg-gray-50' : 'border-green-200 bg-green-50 text-green-600 hover:bg-green-100'}`}
                  title={template.active ? "Pause Template" : "Activate Template"}
                >
                  <Power className="h-5 w-5" />
                </button>
                <button className="p-2 rounded-lg border border-gray-200 text-gray-500 hover:bg-gray-50 transition-colors">
                  <Edit2 className="h-5 w-5" />
                </button>
              </div>
            </div>

            <div className="rounded-xl bg-gray-50 border border-gray-100 p-5">
              <p className="text-[#222222] whitespace-pre-wrap font-medium leading-relaxed">
                {template.content}
              </p>
            </div>
            
            <div className="mt-4 flex gap-2">
              {['{guest_name}', '{property_name}', '{check_in_date}', '{door_code}'].map(tag => (
                <span key={tag} className="px-2 py-1 bg-gray-100 text-gray-500 rounded text-xs font-mono">
                  {tag}
                </span>
              ))}
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
