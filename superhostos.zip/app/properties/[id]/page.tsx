'use client';

import { useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { db } from '@/firebase';
import { doc, getDoc, collection, query, where, getDocs } from 'firebase/firestore';
import { useAuth } from '@/components/Navbar';
import { motion } from 'motion/react';
import { ArrowLeft, MapPin, TrendingUp, AlertTriangle, CheckCircle2, Loader2, BedDouble, Users, Calendar, ShieldCheck } from 'lucide-react';
import Link from 'next/link';
import { cn } from '@/lib/utils';

export default function PropertyDetailsPage() {
  const { id } = useParams();
  const { user, loading: authLoading } = useAuth();
  const router = useRouter();
  
  const [property, setProperty] = useState<any>(null);
  const [metrics, setMetrics] = useState<any>(null);
  const [prediction, setPrediction] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (authLoading || !user) return;

    const fetchDetails = async () => {
      try {
        const propDoc = await getDoc(doc(db, 'properties', id as string));
        if (propDoc.exists()) {
          setProperty({ id: propDoc.id, ...propDoc.data() });
        }

        // Fetch metrics
        const metricsQuery = query(collection(db, 'metrics'), where('property_id', '==', id));
        const metricsSnap = await getDocs(metricsQuery);
        if (!metricsSnap.empty) {
          setMetrics({ id: metricsSnap.docs[0].id, ...metricsSnap.docs[0].data() });
        }

        // Fetch prediction
        const predDoc = await getDoc(doc(db, 'predictions', id as string));
        if (predDoc.exists()) {
          setPrediction({ id: predDoc.id, ...predDoc.data() });
        }
      } catch (error) {
        console.error("Error fetching property details:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchDetails();
  }, [id, authLoading, user]);

  if (authLoading || loading) {
    return (
      <div className="flex h-[60vh] items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-[#FF385C]" />
      </div>
    );
  }

  if (!property) {
    return (
      <div className="text-center py-20">
        <h2 className="text-2xl font-bold text-[#222222]">Property Not Found</h2>
        <p className="text-[#717171] mt-2">The property you are looking for does not exist.</p>
        <Link href="/" className="mt-6 inline-flex items-center gap-2 text-[#FF385C] font-semibold hover:underline">
          <ArrowLeft className="h-4 w-4" /> Back to Dashboard
        </Link>
      </div>
    );
  }

  const sr = prediction ? Math.round(prediction.stay_readiness) : 0;
  const risk = prediction?.risk_level || 'UNKNOWN';

  return (
    <div className="max-w-5xl mx-auto space-y-8 pb-24">
      <Link href="/" className="inline-flex items-center gap-2 text-sm font-semibold text-[#717171] hover:text-[#222222] transition-colors">
        <ArrowLeft className="h-4 w-4" /> Back to Dashboard
      </Link>

      <div className="flex flex-col md:flex-row md:items-start justify-between gap-6 border-b border-gray-200 pb-8">
        <div>
          <h1 className="text-4xl font-bold text-[#222222] tracking-tight">{property.name}</h1>
          <div className="flex items-center gap-4 mt-3 text-[#717171] font-medium">
            <span className="flex items-center gap-1"><MapPin className="h-4 w-4" /> {property.city}, {property.country}</span>
            <span className="flex items-center gap-1"><BedDouble className="h-4 w-4" /> {property.bedrooms} Bedrooms</span>
            <span className="flex items-center gap-1"><Users className="h-4 w-4" /> Max {property.max_guests} Guests</span>
          </div>
        </div>
        <div className="flex flex-col items-end gap-2">
          <div className={cn(
            "px-4 py-1.5 rounded-full text-sm font-bold uppercase tracking-wider border",
            risk === 'CRITICAL' ? 'text-red-700 bg-red-100 border-red-200' :
            risk === 'HIGH' ? 'text-orange-700 bg-orange-100 border-orange-200' :
            risk === 'STOCKOUT' ? 'text-yellow-700 bg-yellow-100 border-yellow-200' :
            'text-green-700 bg-green-100 border-green-200'
          )}>
            {risk} RISK
          </div>
          <div className="text-sm font-semibold text-gray-500">
            Owner: {property.owner_name}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Stay Readiness */}
        <div className="rounded-3xl border border-gray-200 bg-white p-8 shadow-sm md:col-span-2">
          <h3 className="text-lg font-bold text-[#222222] mb-6 flex items-center gap-2">
            <ShieldCheck className="h-5 w-5 text-[#FF385C]" />
            Stay Readiness Score
          </h3>
          <div className="flex items-end gap-4 mb-4">
            <span className="text-6xl font-bold text-[#222222]">{sr}<span className="text-3xl text-gray-400">%</span></span>
          </div>
          <div className="h-3 w-full overflow-hidden rounded-full bg-gray-100">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${sr}%` }}
              transition={{ duration: 1, ease: "easeOut" }}
              className={cn("h-full rounded-full", sr < 60 ? 'bg-[#FF385C]' : sr < 75 ? 'bg-orange-500' : 'bg-green-500')}
            />
          </div>
          <p className="mt-4 text-sm text-[#717171] font-medium">
            This score is calculated by AI based on inventory levels, recent cleaning audits, and maintenance reports.
          </p>
        </div>

        {/* Quick Stats */}
        <div className="space-y-6">
          <div className="rounded-3xl border border-gray-200 bg-white p-6 shadow-sm">
            <div className="text-xs font-bold uppercase tracking-wider text-gray-500 mb-1">Occupancy Rate</div>
            <div className="text-3xl font-bold text-[#222222]">{metrics ? Math.round(metrics.occupancy * 100) : 0}%</div>
          </div>
          <div className="rounded-3xl border border-gray-200 bg-white p-6 shadow-sm">
            <div className="text-xs font-bold uppercase tracking-wider text-gray-500 mb-1">Total Revenue</div>
            <div className="text-3xl font-bold text-[#222222]">${metrics ? metrics.revenue.toLocaleString() : 0}</div>
          </div>
        </div>
      </div>

      {/* Detailed Metrics Grid */}
      <div className="mt-8">
        <h3 className="text-xl font-bold text-[#222222] mb-6">Operational Metrics</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          <MetricCard title="Cleaning Score" value={`${metrics?.cleaning_score || 0}/100`} flag={metrics?.cleaning_flag} />
          <MetricCard title="Linen Score" value={`${metrics?.linen_score || 0}/100`} />
          <MetricCard title="Maintenance" value={`${metrics?.maintenance_score || 0}/100`} flag={metrics?.maintenance_flag} />
          <MetricCard title="Inventory Health" value={`${metrics?.inventory_health || 0}%`} flag={metrics?.restock_flag} />
        </div>
      </div>
    </div>
  );
}

function MetricCard({ title, value, flag }: { title: string, value: string | number, flag?: boolean }) {
  return (
    <div className="rounded-2xl border border-gray-200 bg-white p-5 shadow-sm">
      <div className="flex items-start justify-between mb-2">
        <div className="text-xs font-bold uppercase tracking-wider text-gray-500">{title}</div>
        {flag !== undefined && (
          flag ? <AlertTriangle className="h-4 w-4 text-red-500" /> : <CheckCircle2 className="h-4 w-4 text-green-500" />
        )}
      </div>
      <div className="text-2xl font-bold text-[#222222]">{value}</div>
    </div>
  );
}
