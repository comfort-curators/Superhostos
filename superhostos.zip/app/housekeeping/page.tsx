'use client';

import { useEffect, useState } from 'react';
import { db } from '@/firebase';
import { collection, onSnapshot, getDocs } from 'firebase/firestore';
import { useAuth } from '@/components/Navbar';
import { motion } from 'motion/react';
import { Brush, Calendar, MapPin, Loader2, CheckCircle2, Clock } from 'lucide-react';

export default function HousekeepingPage() {
  const { user, loading: authLoading } = useAuth();
  const [tasks, setTasks] = useState<any[]>([]);
  const [properties, setProperties] = useState<Record<string, any>>({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (authLoading || !user) return;

    const fetchProperties = async () => {
      const propSnap = await getDocs(collection(db, 'properties'));
      const propData: Record<string, any> = {};
      propSnap.docs.forEach(doc => {
        propData[doc.id] = doc.data();
      });
      setProperties(propData);
    };

    fetchProperties().then(() => {
      const unsubscribe = onSnapshot(collection(db, 'cleaning_tasks'), (snapshot) => {
        const tasksData = snapshot.docs.map(d => ({ id: d.id, ...d.data() })) as any[];
        // Sort by date (mocking simple string sort for YYYY-MM-DD)
        tasksData.sort((a, b) => (a.task_date > b.task_date ? 1 : -1));
        setTasks(tasksData);
        setLoading(false);
      });

      return () => unsubscribe();
    });
  }, [authLoading, user]);

  if (authLoading || loading) {
    return (
      <div className="flex h-[60vh] items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-[#FF385C]" />
      </div>
    );
  }

  if (!user) {
    return <div className="text-center py-20 text-gray-500">Please sign in to access the housekeeping schedule.</div>;
  }

  const scheduledTasks = tasks.filter(t => t.status === 'scheduled');
  const completedTasks = tasks.filter(t => t.status === 'completed');

  return (
    <div className="max-w-6xl mx-auto space-y-10 pb-24">
      <div className="flex items-center justify-between border-b border-gray-200 pb-6">
        <div className="flex items-center gap-6">
          <div className="h-16 w-16 rounded-full bg-emerald-50 flex items-center justify-center border border-emerald-100">
            <Brush className="h-8 w-8 text-emerald-600" />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-[#222222] tracking-tight">Housekeeping Schedule</h1>
            <p className="text-[#717171] mt-1 font-medium">Track cleaning status across all properties.</p>
          </div>
        </div>
        <div className="flex gap-4">
          <div className="px-4 py-2 bg-gray-50 rounded-lg border border-gray-200 text-center">
            <div className="text-2xl font-bold text-[#222222]">{scheduledTasks.length}</div>
            <div className="text-xs font-bold uppercase tracking-wider text-gray-500">Upcoming</div>
          </div>
          <div className="px-4 py-2 bg-emerald-50 rounded-lg border border-emerald-200 text-center">
            <div className="text-2xl font-bold text-emerald-700">{completedTasks.length}</div>
            <div className="text-xs font-bold uppercase tracking-wider text-emerald-600">Completed</div>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-3xl border border-gray-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-gray-50 border-b border-gray-200">
                <th className="p-5 text-xs font-bold uppercase tracking-wider text-gray-500">Date</th>
                <th className="p-5 text-xs font-bold uppercase tracking-wider text-gray-500">Property</th>
                <th className="p-5 text-xs font-bold uppercase tracking-wider text-gray-500">Location</th>
                <th className="p-5 text-xs font-bold uppercase tracking-wider text-gray-500">Status</th>
                <th className="p-5 text-xs font-bold uppercase tracking-wider text-gray-500 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {tasks.length === 0 ? (
                <tr>
                  <td colSpan={5} className="p-10 text-center text-gray-500 font-medium">
                    No housekeeping tasks found.
                  </td>
                </tr>
              ) : (
                tasks.map((task) => {
                  const property = properties[task.property_id];
                  const isCompleted = task.status === 'completed';
                  
                  return (
                    <tr key={task.id} className="hover:bg-gray-50 transition-colors">
                      <td className="p-5">
                        <div className="flex items-center gap-2 font-semibold text-[#222222]">
                          <Calendar className="h-4 w-4 text-gray-400" />
                          {task.task_date}
                        </div>
                      </td>
                      <td className="p-5 font-bold text-[#222222]">
                        {property?.name || 'Unknown Property'}
                      </td>
                      <td className="p-5">
                        <div className="flex items-center gap-1 text-sm text-[#717171] font-medium">
                          <MapPin className="h-4 w-4" />
                          {property?.city || 'Unknown'}
                        </div>
                      </td>
                      <td className="p-5">
                        {isCompleted ? (
                          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-green-100 text-green-700 text-xs font-bold uppercase tracking-wider">
                            <CheckCircle2 className="h-3.5 w-3.5" />
                            Cleaned
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-yellow-100 text-yellow-700 text-xs font-bold uppercase tracking-wider">
                            <Clock className="h-3.5 w-3.5" />
                            Scheduled
                          </span>
                        )}
                      </td>
                      <td className="p-5 text-right">
                        <button className="text-sm font-semibold text-[#FF385C] hover:text-[#E31C5F] transition-colors">
                          View Details
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
