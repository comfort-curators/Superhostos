'use client';

import { useEffect, useState } from 'react';
import { db } from '@/firebase';
import { collection, onSnapshot, query, getDocs, addDoc, serverTimestamp, setDoc, doc } from 'firebase/firestore';
import { PropertyCard } from '@/components/PropertyCard';
import { AddPropertyModal } from '@/components/AddPropertyModal';
import { useAuth } from '@/components/Navbar';
import { motion, AnimatePresence } from 'motion/react';
import { LayoutDashboard, Package, Brush, Wrench, Plus, Database, Loader2, Sparkles, MapPin, MessageSquare, ShoppingCart } from 'lucide-react';
import Link from 'next/link';

import { handleFirestoreError, OperationType } from '@/lib/firestore-errors';

export default function Dashboard() {
  const { user, loading: authLoading, isAdmin } = useAuth();
  const [properties, setProperties] = useState<any[]>([]);
  const [predictions, setPredictions] = useState<Record<string, any>>({});
  const [metrics, setMetrics] = useState<Record<string, any>>({});
  const [tasks, setTasks] = useState({ orders: 0, cleaning: 0, maintenance: 0 });
  const [loading, setLoading] = useState(true);
  const [isAddPropertyOpen, setIsAddPropertyOpen] = useState(false);

  const [searchQuery, setSearchQuery] = useState('');
  const [riskFilter, setRiskFilter] = useState('ALL');

  useEffect(() => {
    if (authLoading || !user) return;

    // Fetch Properties
    const unsubscribeProps = onSnapshot(collection(db, 'properties'), (snapshot) => {
      const props = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setProperties(props);
    }, (error) => handleFirestoreError(error, OperationType.GET, 'properties'));

    // Fetch Predictions
    const unsubscribePreds = onSnapshot(collection(db, 'predictions'), (snapshot) => {
      const preds: Record<string, any> = {};
      snapshot.docs.forEach(doc => {
        preds[doc.id] = doc.data();
      });
      setPredictions(preds);
    }, (error) => handleFirestoreError(error, OperationType.GET, 'predictions'));

    // Fetch Metrics
    const unsubscribeMetrics = onSnapshot(collection(db, 'metrics'), (snapshot) => {
      const metricsData: Record<string, any> = {};
      snapshot.docs.forEach(doc => {
        const data = doc.data();
        if (data.property_id) {
          metricsData[data.property_id] = data;
        }
      });
      setMetrics(metricsData);
    }, (error) => handleFirestoreError(error, OperationType.GET, 'metrics'));

    // Fetch Tasks Counts
    const unsubscribeOrders = onSnapshot(query(collection(db, 'orders')), (snap) => {
      setTasks(prev => ({ ...prev, orders: snap.docs.filter(d => d.data().status === 'pending').length }));
    }, (error) => handleFirestoreError(error, OperationType.GET, 'orders'));
    const unsubscribeCleaning = onSnapshot(query(collection(db, 'cleaning_tasks')), (snap) => {
      setTasks(prev => ({ ...prev, cleaning: snap.docs.filter(d => d.data().status === 'scheduled').length }));
    }, (error) => handleFirestoreError(error, OperationType.GET, 'cleaning_tasks'));
    const unsubscribeMaintenance = onSnapshot(query(collection(db, 'maintenance_tasks')), (snap) => {
      setTasks(prev => ({ ...prev, maintenance: snap.docs.filter(d => d.data().status === 'open').length }));
      setLoading(false);
    }, (error) => handleFirestoreError(error, OperationType.GET, 'maintenance_tasks'));

    return () => {
      unsubscribeProps();
      unsubscribePreds();
      unsubscribeMetrics();
      unsubscribeOrders();
      unsubscribeCleaning();
      unsubscribeMaintenance();
    };
  }, [authLoading, user]);

  const seedData = async () => {
    const props = [
      { id: 'PROP001', name: 'Azure Bay Villa', city: 'Malibu', country: 'USA', bedrooms: 4, max_guests: 8, owner_name: 'John Doe', amenities: ['WiFi', 'Pool', 'Free Parking', 'Kitchen'] },
      { id: 'PROP002', name: 'Mountain Retreat', city: 'Aspen', country: 'USA', bedrooms: 3, max_guests: 6, owner_name: 'Jane Smith', amenities: ['WiFi', 'Hot Tub', 'Ski-in/Ski-out', 'Fireplace'] },
      { id: 'PROP003', name: 'Urban Loft', city: 'New York', country: 'USA', bedrooms: 2, max_guests: 4, owner_name: 'Mike Ross', amenities: ['WiFi', 'Gym', 'City Skyline View', 'Elevator'] },
    ];

    for (const p of props) {
      await setDoc(doc(db, 'properties', p.id), { ...p, created_at: serverTimestamp() });
      
      // Initial Metrics
      const metrics = {
        property_id: p.id,
        revenue: 5000,
        occupancy: 0.8,
        adr: 250,
        revpar: 200,
        inventory_health: 85,
        audit_score: 4.5,
        cleaning_score: 90,
        linen_score: 80,
        maintenance_score: 75,
        stock_days: 15,
        lead_time: 5,
        restock_flag: false,
        cleaning_flag: false,
        maintenance_flag: false,
        updated_at: serverTimestamp(),
      };
      await addDoc(collection(db, 'metrics'), metrics);

      // Initial Prediction
      await setDoc(doc(db, 'predictions', p.id), {
        property_id: p.id,
        stay_readiness: 82,
        risk_level: 'LOW',
        updated_at: serverTimestamp(),
      });
    }
  };

  if (authLoading || loading) {
    return (
      <div className="flex h-[60vh] items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-[#FF385C]" />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="relative min-h-[85vh] flex flex-col items-center justify-center overflow-hidden bg-white">
        <div className="relative z-10 w-full max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-16 items-center px-4 md:px-12">
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-7 space-y-8"
          >
            <h1 className="text-5xl md:text-7xl lg:text-[90px] font-bold text-[#222222] leading-[1.05] tracking-tight">
              Manage your properties <br />
              <span className="text-[#FF385C]">like a Superhost.</span>
            </h1>
            
            <p className="text-xl md:text-2xl text-[#717171] max-w-xl leading-relaxed font-medium">
              The all-in-one operating system for modern property management. 
              Automate readiness, predict risks, and deliver perfect stays every time.
            </p>

            <div className="flex flex-wrap items-center gap-6 pt-4">
              <button 
                onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
                className="group relative px-8 py-4 bg-[#FF385C] text-white font-semibold text-lg rounded-xl overflow-hidden transition-all hover:bg-[#E31C5F] active:scale-95"
              >
                Get Started
              </button>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1.5, delay: 0.3, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-5 relative"
          >
            {/* Light Glass Panel */}
            <div className="relative rounded-3xl border border-gray-200 bg-white p-8 shadow-xl overflow-hidden">
              <div className="space-y-8 relative z-10">
                <div className="flex items-center justify-between border-b border-gray-100 pb-6">
                  <div className="text-xs font-bold text-gray-500 uppercase tracking-wider">System Status</div>
                  <div className="flex items-center gap-2 text-sm font-semibold text-green-600">
                    <div className="h-2 w-2 rounded-full bg-green-500 animate-pulse" />
                    Optimal
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <div className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Portfolio Readiness</div>
                    <div className="text-4xl font-bold text-[#222222]">98.4<span className="text-xl text-gray-400">%</span></div>
                  </div>
                  <div className="space-y-2">
                    <div className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Global Risk Level</div>
                    <div className="text-2xl font-bold text-green-600 tracking-widest mt-2">LOW</div>
                  </div>
                </div>

                <div className="pt-6 border-t border-gray-100">
                  <div className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-4">Active Properties</div>
                  <div className="space-y-4">
                    {[1, 2, 3].map((i) => (
                      <div key={i} className="flex items-center gap-4">
                        <div className="h-10 w-10 rounded-full bg-gray-50 border border-gray-200 flex items-center justify-center">
                          <MapPin className="h-4 w-4 text-gray-400" />
                        </div>
                        <div className="flex-1">
                          <div className="h-2 w-full bg-gray-100 rounded-full overflow-hidden">
                            <div className={`h-full bg-[#FF385C] w-[${100 - i * 15}%]`} />
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Floating Accent */}
            <motion.div
              animate={{ y: [0, -10, 0] }}
              transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
              className="absolute -bottom-8 -left-8 p-6 rounded-2xl border border-gray-200 bg-white shadow-xl"
            >
              <div className="flex items-center gap-4">
                <div className="h-12 w-12 rounded-full bg-red-50 flex items-center justify-center border border-red-100">
                  <Sparkles className="h-5 w-5 text-[#FF385C]" />
                </div>
                <div>
                  <div className="text-xs font-semibold text-gray-500 uppercase tracking-wider">AI Prediction</div>
                  <div className="text-sm font-bold text-[#222222] mt-1">100% Ready</div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        </div>

        {/* Feature Grid */}
        <div className="relative z-10 w-full max-w-7xl mx-auto mt-32 grid grid-cols-1 md:grid-cols-3 gap-8 px-4 md:px-12 pb-20">
          <FeatureItem 
            icon={<LayoutDashboard className="h-6 w-6 text-[#FF385C]" />}
            title="Centralized Control"
            desc="Manage your entire portfolio from a single, high-performance interface."
          />
          <FeatureItem 
            icon={<Sparkles className="h-6 w-6 text-[#FF385C]" />}
            title="Predictive AI"
            desc="Anticipate guest needs and property issues before they arise."
          />
          <FeatureItem 
            icon={<Database className="h-6 w-6 text-[#FF385C]" />}
            title="Real-time Sync"
            desc="Instant updates across all portals for vendors, cleaners, and staff."
          />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-12">
      {/* Header Section */}
      <div className="flex flex-col gap-4 md:flex-row md:items-end md:justify-between pb-6 border-b border-gray-200">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-[#222222]">
            Welcome back, {user?.displayName?.split(' ')[0] || 'Superhost'}!
          </h1>
          <p className="mt-2 text-[#717171]">Here is your portfolio overview and operational readiness.</p>
        </div>
        {isAdmin && properties.length === 0 && (
          <button
            onClick={seedData}
            className="flex items-center gap-2 rounded-lg bg-[#FF385C] px-6 py-3 text-sm font-semibold text-white hover:bg-[#E31C5F] transition-colors"
          >
            <Database className="h-4 w-4" />
            Seed Initial Data
          </button>
        )}
      </div>

      {/* OS Modules Grid */}
      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
        <Link href="/messages" className="group block">
          <div className="rounded-2xl border border-gray-200 bg-white p-6 shadow-sm hover:shadow-md transition-all hover:-translate-y-1 h-full">
            <div className="flex items-center gap-4 mb-4">
              <div className="rounded-xl bg-blue-50 p-3 border border-blue-100 group-hover:scale-110 transition-transform">
                <MessageSquare className="h-6 w-6 text-blue-600" />
              </div>
            </div>
            <h3 className="text-lg font-bold text-[#222222] mb-1">Automated Messages</h3>
            <p className="text-sm text-[#717171] font-medium">Manage scheduled guest communications.</p>
          </div>
        </Link>

        <Link href="/housekeeping" className="group block">
          <div className="rounded-2xl border border-gray-200 bg-white p-6 shadow-sm hover:shadow-md transition-all hover:-translate-y-1 h-full">
            <div className="flex items-center gap-4 mb-4">
              <div className="rounded-xl bg-emerald-50 p-3 border border-emerald-100 group-hover:scale-110 transition-transform">
                <Brush className="h-6 w-6 text-emerald-600" />
              </div>
            </div>
            <h3 className="text-lg font-bold text-[#222222] mb-1">Housekeeping</h3>
            <p className="text-sm text-[#717171] font-medium">Track cleaning schedule across properties.</p>
          </div>
        </Link>

        <Link href="/shop" className="group block">
          <div className="rounded-2xl border border-gray-200 bg-white p-6 shadow-sm hover:shadow-md transition-all hover:-translate-y-1 h-full">
            <div className="flex items-center gap-4 mb-4">
              <div className="rounded-xl bg-amber-50 p-3 border border-amber-100 group-hover:scale-110 transition-transform">
                <ShoppingCart className="h-6 w-6 text-amber-600" />
              </div>
            </div>
            <h3 className="text-lg font-bold text-[#222222] mb-1">Inventory Shop</h3>
            <p className="text-sm text-[#717171] font-medium">Order supplies and restock essentials.</p>
          </div>
        </Link>

        <a href="#properties" className="group block">
          <div className="rounded-2xl border border-gray-200 bg-white p-6 shadow-sm hover:shadow-md transition-all hover:-translate-y-1 h-full">
            <div className="flex items-center gap-4 mb-4">
              <div className="rounded-xl bg-purple-50 p-3 border border-purple-100 group-hover:scale-110 transition-transform">
                <LayoutDashboard className="h-6 w-6 text-purple-600" />
              </div>
            </div>
            <h3 className="text-lg font-bold text-[#222222] mb-1">Properties</h3>
            <p className="text-sm text-[#717171] font-medium">View status and risk levels for all listings.</p>
          </div>
        </a>
      </div>

      {/* Properties Grid */}
      <div id="properties" className="pt-8">
        <div className="mb-8 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h2 className="text-2xl font-bold text-[#222222]">Managed Properties</h2>
            <span className="text-sm font-semibold text-gray-500 uppercase tracking-wider">{properties.length} Total</span>
          </div>
          
          <div className="flex flex-col sm:flex-row items-center gap-3">
            <input 
              type="text" 
              placeholder="Search properties..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full sm:w-64 rounded-xl bg-white border border-gray-200 px-4 py-2.5 text-sm font-medium text-[#222222] focus:border-[#FF385C] focus:ring-1 focus:ring-[#FF385C] outline-none transition-all shadow-sm"
            />
            
            <select 
              value={riskFilter}
              onChange={(e) => setRiskFilter(e.target.value)}
              className="w-full sm:w-auto rounded-xl bg-white border border-gray-200 px-4 py-2.5 text-sm font-medium text-[#222222] focus:border-[#FF385C] focus:ring-1 focus:ring-[#FF385C] outline-none transition-all shadow-sm"
            >
              <option value="ALL">All Risks</option>
              <option value="LOW">Low Risk</option>
              <option value="HIGH">High Risk</option>
              <option value="CRITICAL">Critical</option>
              <option value="STOCKOUT">Stockout</option>
            </select>

            <button 
              onClick={() => setIsAddPropertyOpen(true)}
              className="w-full sm:w-auto flex items-center justify-center gap-2 rounded-xl bg-[#FF385C] border border-transparent px-4 py-2.5 text-sm font-semibold text-white hover:bg-[#E31C5F] transition-colors shadow-sm"
            >
              <Plus className="h-4 w-4" />
              Add Property
            </button>
          </div>
        </div>
        
        {properties.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-gray-300 bg-gray-50 p-16 text-center">
            <p className="text-gray-500 font-medium">No properties found. Use the seed button to get started.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
            {properties.filter(p => {
              const matchesSearch = p.name.toLowerCase().includes(searchQuery.toLowerCase()) || p.city.toLowerCase().includes(searchQuery.toLowerCase());
              const risk = predictions[p.id]?.risk_level || 'UNKNOWN';
              const matchesRisk = riskFilter === 'ALL' || risk === riskFilter;
              return matchesSearch && matchesRisk;
            }).map(p => (
              <PropertyCard 
                key={p.id} 
                property={p} 
                prediction={predictions[p.id] || { stay_readiness: 0, risk_level: 'UNKNOWN' }} 
                metrics={metrics[p.id] || { occupancy: 0, revenue: 0 }}
              />
            ))}
          </div>
        )}
      </div>

      <AddPropertyModal 
        isOpen={isAddPropertyOpen} 
        onClose={() => setIsAddPropertyOpen(false)} 
      />
    </div>
  );
}

function StatCard({ icon, label, value }: { icon: React.ReactNode; label: string; value: number }) {
  return (
    <div className="rounded-2xl border border-gray-200 bg-white p-6 shadow-sm hover:shadow-md transition-shadow">
      <div className="flex items-center gap-4">
        <div className="rounded-xl bg-red-50 p-3 border border-red-100">
          {icon}
        </div>
        <div>
          <div className="text-xs font-bold uppercase tracking-wider text-gray-500 mb-1">{label}</div>
          <div className="text-3xl font-bold text-[#222222]">{value}</div>
        </div>
      </div>
    </div>
  );
}

function FeatureItem({ icon, title, desc }: { icon: React.ReactNode; title: string; desc: string }) {
  return (
    <div className="flex flex-col items-start gap-4 p-6 rounded-2xl bg-gray-50 border border-gray-100">
      <div className="rounded-xl bg-white p-3 shadow-sm border border-gray-200">
        {icon}
      </div>
      <div>
        <h3 className="text-lg font-bold text-[#222222] mb-2">{title}</h3>
        <p className="text-[#717171] leading-relaxed">{desc}</p>
      </div>
    </div>
  );
}
