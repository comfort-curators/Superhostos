'use client';

import { useEffect, useState } from 'react';
import { db } from '@/firebase';
import { collection, onSnapshot, query, where, updateDoc, doc, getDoc } from 'firebase/firestore';
import { useAuth } from '@/components/Navbar';
import { motion, AnimatePresence } from 'motion/react';
import { Brush, CheckCircle2, Loader2, MapPin, Calendar } from 'lucide-react';

import { handleFirestoreError, OperationType } from '@/lib/firestore-errors';

export default function CleanerPortal() {
  const { user, loading: authLoading } = useAuth();
  const [tasks, setTasks] = useState<any[]>([]);
  const [properties, setProperties] = useState<Record<string, any>>({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (authLoading || !user) return;

    const unsubscribe = onSnapshot(
      query(collection(db, 'cleaning_tasks'), where('status', '==', 'scheduled')),
      async (snapshot) => {
        const tasksData = snapshot.docs.map(d => ({ id: d.id, ...d.data() })) as any[];
        setTasks(tasksData);

        const propIds = Array.from(new Set(tasksData.map(t => t.property_id)));
        const propData: Record<string, any> = {};
        for (const id of propIds) {
          const pDoc = await getDoc(doc(db, 'properties', id));
          if (pDoc.exists()) propData[id] = pDoc.data();
        }
        setProperties(propData);
        setLoading(false);
      },
      (error) => handleFirestoreError(error, OperationType.GET, 'cleaning_tasks')
    );

    return () => unsubscribe();
  }, [authLoading, user]);

  const completeTask = async (id: string) => {
    await updateDoc(doc(db, 'cleaning_tasks', id), { status: 'completed' });
  };

  if (authLoading || loading) {
    return (
      <div className="flex h-[60vh] items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-[#FF385C]" />
      </div>
    );
  }

  if (!user) return <div className="text-center py-20 text-zinc-500">Please sign in to access the portal.</div>;

  return (
    <div className="space-y-10">
      <div className="flex items-center gap-6 border-b border-gray-200 pb-6">
        <div className="h-16 w-16 rounded-full bg-green-50 flex items-center justify-center border border-green-100">
          <Brush className="h-8 w-8 text-green-600" />
        </div>
        <div>
          <h1 className="text-3xl font-bold text-[#222222] tracking-tight">Cleaner Portal</h1>
          <p className="text-[#717171] mt-1 font-medium">Manage property cleaning schedules and completion.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
        <AnimatePresence mode="popLayout">
          {tasks.length === 0 ? (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="col-span-full rounded-2xl border border-dashed border-gray-300 bg-gray-50 p-20 text-center"
            >
              <CheckCircle2 className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-500 font-medium">No scheduled cleaning tasks. All properties are spotless.</p>
            </motion.div>
          ) : (
            tasks.map(task => (
              <motion.div
                key={task.id}
                layout
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                className="rounded-2xl border border-gray-200 bg-white p-6 shadow-sm hover:shadow-md transition-shadow"
              >
                <div className="flex items-start justify-between mb-6">
                  <div>
                    <div className="text-xs font-bold uppercase tracking-wider text-gray-500 mb-1">Task ID: {task.id.slice(0, 8)}</div>
                    <h3 className="text-lg font-bold text-[#222222]">{properties[task.property_id]?.name || 'Unknown Property'}</h3>
                    <div className="flex items-center gap-1 text-sm text-[#717171] mt-1">
                      <MapPin className="h-4 w-4" />
                      {properties[task.property_id]?.city || 'Unknown City'}
                    </div>
                  </div>
                  <div className="rounded-full border border-green-200 bg-green-100 px-3 py-1 text-xs font-bold text-green-700 uppercase tracking-wider">Scheduled</div>
                </div>

                <div className="rounded-xl bg-gray-50 p-4 border border-gray-100 mb-6">
                  <div className="text-xs font-bold uppercase tracking-wider text-gray-500 mb-1">Scheduled Date:</div>
                  <div className="flex items-center gap-2 text-base font-semibold text-[#222222]">
                    <Calendar className="h-4 w-4 text-green-600" />
                    {task.task_date}
                  </div>
                </div>

                <button
                  onClick={() => completeTask(task.id)}
                  className="w-full flex items-center justify-center gap-2 rounded-lg bg-[#FF385C] px-6 py-3 text-sm font-semibold text-white transition-colors hover:bg-[#E31C5F] active:scale-95"
                >
                  <CheckCircle2 className="h-4 w-4" />
                  Mark as Completed
                </button>
              </motion.div>
            ))
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
