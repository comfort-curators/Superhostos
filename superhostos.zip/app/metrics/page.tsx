'use client';

import { useEffect, useState } from 'react';
import { db } from '@/firebase';
import { collection, onSnapshot, addDoc, serverTimestamp, getDocs, query, where } from 'firebase/firestore';
import { useAuth } from '@/components/Navbar';
import { processMetricsUpdate } from '@/lib/logic';
import { motion } from 'motion/react';
import { BarChart3, Save, Loader2, CheckCircle2, AlertCircle } from 'lucide-react';
import { useForm } from 'react-hook-form';

import { handleFirestoreError, OperationType } from '@/lib/firestore-errors';

export default function MetricsPage() {
  const { user, loading: authLoading, isAdmin } = useAuth();
  const [properties, setProperties] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);

  const { register, handleSubmit, reset, watch } = useForm({
    defaultValues: {
      property_id: '',
      revenue: 0,
      occupancy: 0.8,
      adr: 200,
      revpar: 160,
      inventory_health: 90,
      audit_score: 4.5,
      cleaning_score: 95,
      linen_score: 90,
      maintenance_score: 85,
      stock_days: 20,
      lead_time: 5,
    }
  });

  useEffect(() => {
    if (authLoading || !user || !isAdmin) return;

    const unsubscribe = onSnapshot(collection(db, 'properties'), (snapshot) => {
      setProperties(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
      setLoading(false);
    }, (error) => handleFirestoreError(error, OperationType.GET, 'properties'));

    return () => unsubscribe();
  }, [authLoading, user, isAdmin]);

  const onSubmit = async (data: any) => {
    setSubmitting(true);
    try {
      const metrics = {
        ...data,
        revenue: Number(data.revenue),
        occupancy: Number(data.occupancy),
        adr: Number(data.adr),
        revpar: Number(data.revpar),
        inventory_health: Number(data.inventory_health),
        audit_score: Number(data.audit_score),
        cleaning_score: Number(data.cleaning_score),
        linen_score: Number(data.linen_score),
        maintenance_score: Number(data.maintenance_score),
        stock_days: Number(data.stock_days),
        lead_time: Number(data.lead_time),
        restock_flag: false,
        cleaning_flag: false,
        maintenance_flag: false,
        updated_at: serverTimestamp(),
      };

      await addDoc(collection(db, 'metrics'), metrics);
      await processMetricsUpdate(data.property_id, metrics);
      
      setSuccess(true);
      setTimeout(() => setSuccess(false), 3000);
      reset();
    } catch (error) {
      console.error("Error updating metrics:", error);
    } finally {
      setSubmitting(false);
    }
  };

  if (authLoading || loading) {
    return (
      <div className="flex h-[60vh] items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-[#FF385C]" />
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="flex flex-col items-center justify-center h-[60vh] text-center">
        <AlertCircle className="h-12 w-12 text-red-500 mb-4" />
        <h1 className="text-2xl font-bold text-[#222222]">Access Denied</h1>
        <p className="text-[#717171]">Only administrators can access the metrics input page.</p>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-10">
      <div className="flex items-center gap-6 border-b border-gray-200 pb-6">
        <div className="h-16 w-16 rounded-full bg-blue-50 flex items-center justify-center border border-blue-100">
          <BarChart3 className="h-8 w-8 text-blue-600" />
        </div>
        <div>
          <h1 className="text-3xl font-bold text-[#222222] tracking-tight">Metrics Input</h1>
          <p className="text-[#717171] mt-1 font-medium">Update property metrics to trigger automated analysis.</p>
        </div>
      </div>

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-8 bg-white border border-gray-200 rounded-3xl p-8 shadow-sm">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Property Selection */}
          <div className="col-span-full">
            <label className="block text-xs font-bold uppercase tracking-wider text-gray-500 mb-2">Select Property</label>
            <select
              {...register('property_id', { required: true })}
              className="w-full rounded-xl bg-gray-50 border border-gray-200 p-4 text-sm font-medium text-[#222222] focus:border-[#FF385C] focus:ring-1 focus:ring-[#FF385C] outline-none transition-all"
            >
              <option value="">Choose a property...</option>
              {properties.map(p => (
                <option key={p.id} value={p.id}>{p.name} ({p.city})</option>
              ))}
            </select>
          </div>

          {/* Financial Metrics */}
          <div className="space-y-6">
            <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider border-b border-gray-100 pb-2">Financials</h3>
            <MetricInput label="Revenue ($)" name="revenue" register={register} />
            <MetricInput label="Occupancy (0-1)" name="occupancy" register={register} />
            <MetricInput label="ADR ($)" name="adr" register={register} />
            <MetricInput label="RevPAR ($)" name="revpar" register={register} />
          </div>

          {/* Operational Metrics */}
          <div className="space-y-6">
            <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider border-b border-gray-100 pb-2">Operations</h3>
            <MetricInput label="Inventory Health (0-100)" name="inventory_health" register={register} />
            <MetricInput label="Cleaning Score (0-100)" name="cleaning_score" register={register} />
            <MetricInput label="Linen Score (0-100)" name="linen_score" register={register} />
            <MetricInput label="Maintenance Score (0-100)" name="maintenance_score" register={register} />
          </div>

          {/* Logistics */}
          <div className="space-y-6">
            <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider border-b border-gray-100 pb-2">Logistics</h3>
            <MetricInput label="Stock Days" name="stock_days" register={register} />
            <MetricInput label="Lead Time (Days)" name="lead_time" register={register} />
            <MetricInput label="Audit Score (0-5)" name="audit_score" register={register} />
          </div>
        </div>

        <div className="flex items-center justify-between pt-8 border-t border-gray-100">
          <div className="flex items-center gap-2">
            {success && (
              <motion.div
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                className="flex items-center gap-2 text-green-600 text-sm font-bold uppercase tracking-wider"
              >
                <CheckCircle2 className="h-5 w-5" />
                Metrics Updated Successfully
              </motion.div>
            )}
          </div>
          <button
            type="submit"
            disabled={submitting}
            className="flex items-center gap-2 rounded-xl bg-[#FF385C] px-8 py-4 text-sm font-semibold text-white transition-colors hover:bg-[#E31C5F] active:scale-95 disabled:opacity-50"
          >
            {submitting ? <Loader2 className="h-5 w-5 animate-spin" /> : <Save className="h-5 w-5" />}
            {submitting ? 'Processing...' : 'Save Metrics'}
          </button>
        </div>
      </form>
    </div>
  );
}

function MetricInput({ label, name, register }: { label: string; name: string; register: any }) {
  return (
    <div>
      <label className="block text-xs font-semibold text-[#717171] mb-1">{label}</label>
      <input
        type="number"
        step="any"
        {...register(name)}
        className="w-full rounded-lg bg-gray-50 border border-gray-200 p-3 text-sm font-medium text-[#222222] focus:border-[#FF385C] focus:ring-1 focus:ring-[#FF385C] outline-none transition-all"
      />
    </div>
  );
}
