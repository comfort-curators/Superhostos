'use client';

import { useAuth } from '@/components/Navbar';
import { Loader2, LogOut, User as UserIcon, Shield, Mail } from 'lucide-react';
import { useRouter } from 'next/navigation';

export default function AccountPage() {
  const { user, loading, isAdmin, logout } = useAuth();
  const router = useRouter();

  const handleLogout = async () => {
    await logout();
    router.push('/');
  };

  if (loading) {
    return (
      <div className="flex h-[60vh] items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-[#FF385C]" />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="flex flex-col items-center justify-center h-[60vh] text-center">
        <UserIcon className="h-12 w-12 text-gray-400 mb-4" />
        <h1 className="text-2xl font-bold text-[#222222]">Not Signed In</h1>
        <p className="text-[#717171] mt-2">Please sign in to view your account details.</p>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-8 pb-24">
      <div className="flex items-center justify-between border-b border-gray-200 pb-6">
        <div>
          <h1 className="text-3xl font-bold text-[#222222] tracking-tight">My Account</h1>
          <p className="text-[#717171] mt-1 font-medium">Manage your profile and settings.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {/* Profile Card */}
        <div className="md:col-span-1 space-y-6">
          <div className="bg-white rounded-3xl border border-gray-200 p-8 shadow-sm text-center">
            <div className="h-32 w-32 mx-auto rounded-full bg-gray-100 border-4 border-white shadow-lg overflow-hidden flex items-center justify-center text-gray-400 mb-6">
              {user.photoURL ? (
                <img src={user.photoURL} alt={user.displayName || 'User'} className="h-full w-full object-cover" />
              ) : (
                <UserIcon className="h-12 w-12" />
              )}
            </div>
            
            <h2 className="text-2xl font-bold text-[#222222]">{user.displayName || 'Superhost User'}</h2>
            <div className="flex items-center justify-center gap-2 mt-2 text-[#717171] text-sm">
              <Mail className="h-4 w-4" />
              <span>{user.email}</span>
            </div>

            <div className="mt-6">
              <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider ${isAdmin ? 'bg-purple-100 text-purple-700' : 'bg-blue-100 text-blue-700'}`}>
                <Shield className="h-3.5 w-3.5" />
                {isAdmin ? 'Administrator' : 'Staff Member'}
              </span>
            </div>

            <div className="mt-8 pt-6 border-t border-gray-100">
              <button
                onClick={handleLogout}
                className="flex items-center justify-center gap-2 w-full rounded-xl bg-gray-50 border border-gray-200 px-6 py-3 text-sm font-semibold text-red-600 hover:bg-red-50 hover:border-red-100 transition-colors"
              >
                <LogOut className="h-4 w-4" />
                Sign Out
              </button>
            </div>
          </div>
        </div>

        {/* Settings & Preferences */}
        <div className="md:col-span-2 space-y-6">
          <div className="bg-white rounded-3xl border border-gray-200 p-8 shadow-sm">
            <h3 className="text-xl font-bold text-[#222222] mb-6">Notification Preferences</h3>
            <div className="space-y-4">
              <div className="flex items-center justify-between py-3 border-b border-gray-100">
                <div>
                  <div className="font-semibold text-[#222222]">Email Notifications</div>
                  <div className="text-sm text-[#717171]">Receive daily digests and critical alerts.</div>
                </div>
                <div className="w-12 h-6 bg-[#FF385C] rounded-full relative cursor-pointer">
                  <div className="absolute right-1 top-1 bg-white w-4 h-4 rounded-full shadow-sm"></div>
                </div>
              </div>
              <div className="flex items-center justify-between py-3 border-b border-gray-100">
                <div>
                  <div className="font-semibold text-[#222222]">SMS Alerts</div>
                  <div className="text-sm text-[#717171]">Get text messages for STOCKOUT or CRITICAL risks.</div>
                </div>
                <div className="w-12 h-6 bg-[#FF385C] rounded-full relative cursor-pointer">
                  <div className="absolute right-1 top-1 bg-white w-4 h-4 rounded-full shadow-sm"></div>
                </div>
              </div>
              <div className="flex items-center justify-between py-3">
                <div>
                  <div className="font-semibold text-[#222222]">Marketing Updates</div>
                  <div className="text-sm text-[#717171]">Receive news about SuperhostOS features.</div>
                </div>
                <div className="w-12 h-6 bg-gray-200 rounded-full relative cursor-pointer">
                  <div className="absolute left-1 top-1 bg-white w-4 h-4 rounded-full shadow-sm"></div>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-3xl border border-gray-200 p-8 shadow-sm">
            <h3 className="text-xl font-bold text-[#222222] mb-6">Security Settings</h3>
            <div className="space-y-4">
              <button className="w-full text-left py-3 border-b border-gray-100 font-semibold text-[#222222] hover:text-[#FF385C] transition-colors">
                Change Password
              </button>
              <button className="w-full text-left py-3 border-b border-gray-100 font-semibold text-[#222222] hover:text-[#FF385C] transition-colors">
                Two-Factor Authentication (2FA)
              </button>
              <button className="w-full text-left py-3 font-semibold text-red-600 hover:text-red-700 transition-colors">
                Delete Account
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
